module.exports = (a, b) => {
  return a + b;
}
